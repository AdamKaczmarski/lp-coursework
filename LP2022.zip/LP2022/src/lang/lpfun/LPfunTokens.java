package lang.lpfun;

public final class LPfunTokens {

    public static final String[][] DEFS = {
            // define your LPfun tokens here
    };
}
