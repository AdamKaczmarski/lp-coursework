package lang.lpse;

public final class LPseTokens {

    public static final String[][] DEFS = {
            // define your LPse tokens here
    };
}
