package lang.lpop;

import lang.lpse.LPseTokens;

public final class LPopTokens {

    public static final String[][] DEFS = LPseTokens.DEFS;

}
